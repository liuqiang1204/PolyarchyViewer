PRAGMA synchronous = OFF;
PRAGMA journal_mode = MEMORY;
BEGIN TRANSACTION;
CREATE TABLE "atom" (
  "displayName" varchar(45) NOT NULL DEFAULT '',
  "name" varchar(45) DEFAULT NULL,
  "columnName" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("displayName")
);
INSERT INTO "atom" VALUES ('Publications','publications_linking','publicationid');
CREATE TABLE "forcodes_hierarchy" (
  "idhierarchy" int(11) NOT NULL ,
  "parentid" int(11) DEFAULT NULL,
  "Level" int(11) DEFAULT NULL,
  "original_id" int(11) DEFAULT NULL,
  "origin_parent" int(11) DEFAULT NULL,
  "Label" varchar(95) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "forcodes_hierarchy" VALUES (1,0,1,1,0,'001');
INSERT INTO "forcodes_hierarchy" VALUES (2,0,1,1,0,'002');
CREATE TABLE "hierarchy" (
  "idhierarchy" int(11) NOT NULL,
  "name" varchar(45) DEFAULT NULL,
  "level" int(11) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "hierarchy" VALUES (1,'forcodes_hierarchy',1);
INSERT INTO "hierarchy" VALUES (2,'staff_hierarchy',1);
INSERT INTO "hierarchy" VALUES (3,'theme_hierarchy',2);
CREATE TABLE "publications_forcodes" (
  "idpublications_forcodes" int(11) NOT NULL ,
  "publicationid" int(11) DEFAULT NULL,
  "forcodeid" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idpublications_forcodes")
);
INSERT INTO "publications_forcodes" VALUES (1,1,1,'0.50');
INSERT INTO "publications_forcodes" VALUES (2,1,2,'0.50');
INSERT INTO "publications_forcodes" VALUES (3,2,1,'1.00');
INSERT INTO "publications_forcodes" VALUES (4,3,1,'0.50');
INSERT INTO "publications_forcodes" VALUES (5,3,2,'0.50');
INSERT INTO "publications_forcodes" VALUES (6,4,1,'1.00');
CREATE TABLE "publications_linking" (
  "idhierarchy" int(11) NOT NULL DEFAULT '0',
  "name" varchar(45) DEFAULT NULL,
  "columnName" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "publications_linking" VALUES (1,'publications_forcodes','forcodeid');
INSERT INTO "publications_linking" VALUES (2,'publications_researchers','researcherid');
INSERT INTO "publications_linking" VALUES (3,'publications_theme','themeid');
CREATE TABLE "publications_researchers" (
  "idpublications_researchers" int(11) NOT NULL ,
  "publicationid" int(11) DEFAULT NULL,
  "researcherid" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idpublications_researchers")
);
INSERT INTO "publications_researchers" VALUES (1,1,1,'0.50');
INSERT INTO "publications_researchers" VALUES (2,1,3,'0.50');
INSERT INTO "publications_researchers" VALUES (3,2,1,'1.00');
INSERT INTO "publications_researchers" VALUES (4,3,1,'0.50');
INSERT INTO "publications_researchers" VALUES (5,3,2,'0.50');
INSERT INTO "publications_researchers" VALUES (6,4,1,'0.33');
INSERT INTO "publications_researchers" VALUES (7,4,2,'0.33');
INSERT INTO "publications_researchers" VALUES (8,4,4,'0.33');
CREATE TABLE "publications_theme" (
  "idpublications_theme" int(11) NOT NULL ,
  "publicationid" int(11) DEFAULT NULL,
  "themeid" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idpublications_theme")
);
INSERT INTO "publications_theme" VALUES (1,1,3,'0.50');
INSERT INTO "publications_theme" VALUES (2,1,4,'0.50');
INSERT INTO "publications_theme" VALUES (3,2,3,'0.50');
INSERT INTO "publications_theme" VALUES (4,2,4,'0.50');
INSERT INTO "publications_theme" VALUES (5,3,3,'1.00');
INSERT INTO "publications_theme" VALUES (6,4,3,'1.00');
CREATE TABLE "staff_hierarchy" (
  "idhierarchy" int(11) NOT NULL ,
  "parentid" int(11) DEFAULT NULL,
  "level" int(11) DEFAULT NULL,
  "original_id" int(11) DEFAULT NULL,
  "origin_parent" int(11) DEFAULT NULL,
  "label" varchar(105) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "staff_hierarchy" VALUES (1,0,1,1,0,'Michael');
INSERT INTO "staff_hierarchy" VALUES (2,0,1,1,0,'Kim');
INSERT INTO "staff_hierarchy" VALUES (3,0,1,1,0,'John');
INSERT INTO "staff_hierarchy" VALUES (4,0,1,1,0,'Peter');
CREATE TABLE "theme_hierarchy" (
  "idhierarchy" int(11) NOT NULL ,
  "parentid" int(11) DEFAULT NULL,
  "original_id" int(11) DEFAULT NULL,
  "origin_parent" int(11) DEFAULT NULL,
  "label" varchar(95) DEFAULT NULL,
  "level" int(11) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "theme_hierarchy" VALUES (1,0,1,0,'Theme1',1);
INSERT INTO "theme_hierarchy" VALUES (2,0,2,0,'Theme2',1);
INSERT INTO "theme_hierarchy" VALUES (3,1,1,1,'Subtheme1',2);
INSERT INTO "theme_hierarchy" VALUES (4,2,2,2,'Subtheme2',2);
CREATE TABLE "tmptable" (
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  "parentid" int(11) DEFAULT NULL
);
INSERT INTO "tmptable" VALUES ('0.50',1);
INSERT INTO "tmptable" VALUES ('0.50',1);
INSERT INTO "tmptable" VALUES ('1.00',1);
INSERT INTO "tmptable" VALUES ('1.00',1);
INSERT INTO "tmptable" VALUES ('0.50',2);
INSERT INTO "tmptable" VALUES ('0.50',2);
END TRANSACTION;
