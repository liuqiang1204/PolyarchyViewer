PRAGMA synchronous = OFF;
PRAGMA journal_mode = MEMORY;
BEGIN TRANSACTION;
CREATE TABLE "actor_hierarchy" (
  "idhierarchy" int(11) NOT NULL ,
  "parentId" int(11) DEFAULT NULL,
  "original_id" int(11) DEFAULT NULL,
  "origin_parent" int(11) DEFAULT NULL,
  "Label" varchar(45) DEFAULT NULL,
  "Level" int(11) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "actor_hierarchy" VALUES (1,0,1,0,'A',1);
INSERT INTO "actor_hierarchy" VALUES (2,0,2,0,'B',1);
INSERT INTO "actor_hierarchy" VALUES (3,0,3,0,'C',1);
INSERT INTO "actor_hierarchy" VALUES (4,0,4,0,'D',1);
INSERT INTO "actor_hierarchy" VALUES (5,0,5,0,'E',1);
INSERT INTO "actor_hierarchy" VALUES (6,0,6,0,'F',1);
INSERT INTO "actor_hierarchy" VALUES (7,0,7,0,'H',1);
INSERT INTO "actor_hierarchy" VALUES (8,0,8,0,'I',1);
INSERT INTO "actor_hierarchy" VALUES (9,0,9,0,'J',1);
INSERT INTO "actor_hierarchy" VALUES (10,0,10,0,'K',1);
INSERT INTO "actor_hierarchy" VALUES (11,0,11,0,'L',1);
INSERT INTO "actor_hierarchy" VALUES (12,0,12,0,'M',1);
INSERT INTO "actor_hierarchy" VALUES (13,0,13,0,'N',1);
INSERT INTO "actor_hierarchy" VALUES (14,0,14,0,'O',1);
INSERT INTO "actor_hierarchy" VALUES (15,0,15,0,'P',1);
INSERT INTO "actor_hierarchy" VALUES (16,0,16,0,'Q',1);
INSERT INTO "actor_hierarchy" VALUES (17,0,17,0,'R',1);
INSERT INTO "actor_hierarchy" VALUES (18,0,18,0,'S',1);
INSERT INTO "actor_hierarchy" VALUES (19,0,19,0,'T',1);
INSERT INTO "actor_hierarchy" VALUES (20,0,20,0,'U',1);
INSERT INTO "actor_hierarchy" VALUES (21,0,21,0,'V',1);
INSERT INTO "actor_hierarchy" VALUES (22,0,22,0,'W',1);
INSERT INTO "actor_hierarchy" VALUES (23,0,23,0,'X',1);
INSERT INTO "actor_hierarchy" VALUES (24,0,24,0,'Y',1);
INSERT INTO "actor_hierarchy" VALUES (25,0,25,0,'Z',1);
INSERT INTO "actor_hierarchy" VALUES (32,9,1,9,'Johnny Depp',2);
INSERT INTO "actor_hierarchy" VALUES (33,8,2,8,'Isla Fisher',2);
INSERT INTO "actor_hierarchy" VALUES (34,7,3,7,'Hugh Dancy',2);
INSERT INTO "actor_hierarchy" VALUES (35,10,4,10,'Krysten Ritter',2);
INSERT INTO "actor_hierarchy" VALUES (36,1,5,1,'Angelina Jolie',2);
INSERT INTO "actor_hierarchy" VALUES (37,2,6,2,'Bradley Cooper',2);
INSERT INTO "actor_hierarchy" VALUES (38,1,7,1,'Anna Friel',2);
INSERT INTO "actor_hierarchy" VALUES (39,1,8,1,'Abbie Cornish',2);
INSERT INTO "actor_hierarchy" VALUES (40,22,9,22,'Will Ferrel ',2);
INSERT INTO "actor_hierarchy" VALUES (41,4,10,4,'Danny Mcbride',2);
INSERT INTO "actor_hierarchy" VALUES (42,0,26,0,'G',1);
INSERT INTO "actor_hierarchy" VALUES (43,1,11,1,'Actor 1',2);
INSERT INTO "actor_hierarchy" VALUES (44,2,12,2,'Actor 2',2);
INSERT INTO "actor_hierarchy" VALUES (45,3,13,3,'Actor 3',2);
INSERT INTO "actor_hierarchy" VALUES (46,4,14,4,'Actor 4',2);
INSERT INTO "actor_hierarchy" VALUES (47,5,15,5,'Actor 5',2);
INSERT INTO "actor_hierarchy" VALUES (48,6,16,6,'Actor 6',2);
INSERT INTO "actor_hierarchy" VALUES (49,7,17,7,'Actor 7',2);
INSERT INTO "actor_hierarchy" VALUES (50,8,18,8,'Actor 8',2);
INSERT INTO "actor_hierarchy" VALUES (51,9,19,9,'Actor 9',2);
INSERT INTO "actor_hierarchy" VALUES (52,10,20,10,'Actor 10',2);
CREATE TABLE "actors" (
  "idactors" int(11) NOT NULL ,
  "actorsName" varchar(45) DEFAULT NULL,
  "parentID" int(11) DEFAULT NULL,
  PRIMARY KEY ("idactors")
);
INSERT INTO "actors" VALUES (1,'Johnny Depp',9);
INSERT INTO "actors" VALUES (2,'Isla Fisher',8);
INSERT INTO "actors" VALUES (3,'Hugh Dancy',7);
INSERT INTO "actors" VALUES (4,'Krysten Ritter',10);
INSERT INTO "actors" VALUES (5,'Angelina Jolie',1);
INSERT INTO "actors" VALUES (6,'Bradley Cooper',2);
INSERT INTO "actors" VALUES (7,'Anna Friel',1);
INSERT INTO "actors" VALUES (8,'Abbie Cornish',1);
INSERT INTO "actors" VALUES (9,'Will Ferrel ',22);
INSERT INTO "actors" VALUES (10,'Danny Mcbride',4);
INSERT INTO "actors" VALUES (11,'Actor 1',1);
INSERT INTO "actors" VALUES (12,'Actor 2',2);
INSERT INTO "actors" VALUES (13,'Actor 3',3);
INSERT INTO "actors" VALUES (14,'Actor 4',4);
INSERT INTO "actors" VALUES (15,'Actor 5',5);
INSERT INTO "actors" VALUES (16,'Actor 6',6);
INSERT INTO "actors" VALUES (17,'Actor 7',7);
INSERT INTO "actors" VALUES (18,'Actor 8',8);
INSERT INTO "actors" VALUES (19,'Actor 9',9);
INSERT INTO "actors" VALUES (20,'Actor 10',10);
CREATE TABLE "actors_categories" (
  "idactors_categories" int(11) NOT NULL ,
  "categoryName" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idactors_categories")
);
INSERT INTO "actors_categories" VALUES (1,'A');
INSERT INTO "actors_categories" VALUES (2,'B');
INSERT INTO "actors_categories" VALUES (3,'C');
INSERT INTO "actors_categories" VALUES (4,'D');
INSERT INTO "actors_categories" VALUES (5,'E');
INSERT INTO "actors_categories" VALUES (6,'F');
INSERT INTO "actors_categories" VALUES (7,'H');
INSERT INTO "actors_categories" VALUES (8,'I');
INSERT INTO "actors_categories" VALUES (9,'J');
INSERT INTO "actors_categories" VALUES (10,'K');
INSERT INTO "actors_categories" VALUES (11,'L');
INSERT INTO "actors_categories" VALUES (12,'M');
INSERT INTO "actors_categories" VALUES (13,'N');
INSERT INTO "actors_categories" VALUES (14,'O');
INSERT INTO "actors_categories" VALUES (15,'P');
INSERT INTO "actors_categories" VALUES (16,'Q');
INSERT INTO "actors_categories" VALUES (17,'R');
INSERT INTO "actors_categories" VALUES (18,'S');
INSERT INTO "actors_categories" VALUES (19,'T');
INSERT INTO "actors_categories" VALUES (20,'U');
INSERT INTO "actors_categories" VALUES (21,'V');
INSERT INTO "actors_categories" VALUES (22,'W');
INSERT INTO "actors_categories" VALUES (23,'X');
INSERT INTO "actors_categories" VALUES (24,'Y');
INSERT INTO "actors_categories" VALUES (25,'Z');
INSERT INTO "actors_categories" VALUES (26,'G');
CREATE TABLE "atom" (
  "displayName" varchar(45) NOT NULL DEFAULT '',
  "name" varchar(45) DEFAULT NULL,
  "columnName" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("displayName")
);
INSERT INTO "atom" VALUES ('Movies','movies_linking','moviesId');
INSERT INTO "atom" VALUES ('People','people_linking','peopleID');
CREATE TABLE "continent" (
  "idContinent" int(11) NOT NULL,
  "ContinentName" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idContinent")
);
INSERT INTO "continent" VALUES (1,'North America');
INSERT INTO "continent" VALUES (2,'South America');
INSERT INTO "continent" VALUES (3,'Asia');
INSERT INTO "continent" VALUES (4,'Europe');
INSERT INTO "continent" VALUES (5,'Africa');
INSERT INTO "continent" VALUES (6,'Australia');
INSERT INTO "continent" VALUES (7,'Antartica');
CREATE TABLE "country" (
  "idCountry" int(11) NOT NULL,
  "CountryName" varchar(45) DEFAULT NULL,
  "ContinentID" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idCountry")
);
INSERT INTO "country" VALUES (1,'USA','1');
INSERT INTO "country" VALUES (2,'Australia ','6');
INSERT INTO "country" VALUES (3,'Brazil','2');
INSERT INTO "country" VALUES (4,'China','3');
INSERT INTO "country" VALUES (5,'UK ','4');
INSERT INTO "country" VALUES (6,'Country 1','1');
INSERT INTO "country" VALUES (7,'Country 2','1');
INSERT INTO "country" VALUES (8,'Country 3','1');
INSERT INTO "country" VALUES (9,'Country 4','2');
INSERT INTO "country" VALUES (10,'Country 5','3');
INSERT INTO "country" VALUES (11,'Country 6','4');
INSERT INTO "country" VALUES (12,'Country 7','5');
INSERT INTO "country" VALUES (13,'Country 8','6');
CREATE TABLE "country_hierarchy" (
  "idhierarchy" int(11) NOT NULL ,
  "parentId" int(11) DEFAULT NULL,
  "original_id" int(11) DEFAULT NULL,
  "origin_parent" int(11) DEFAULT NULL,
  "Label" varchar(45) DEFAULT NULL,
  "Level" int(11) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "country_hierarchy" VALUES (1,0,1,0,'North America',1);
INSERT INTO "country_hierarchy" VALUES (2,0,2,0,'South America',1);
INSERT INTO "country_hierarchy" VALUES (3,0,3,0,'Asia',1);
INSERT INTO "country_hierarchy" VALUES (4,0,4,0,'Europe',1);
INSERT INTO "country_hierarchy" VALUES (5,0,5,0,'Africa',1);
INSERT INTO "country_hierarchy" VALUES (6,0,6,0,'Australia',1);
INSERT INTO "country_hierarchy" VALUES (7,0,7,0,'Antartica',1);
INSERT INTO "country_hierarchy" VALUES (8,1,1,1,'USA',2);
INSERT INTO "country_hierarchy" VALUES (9,6,2,6,'Australia ',2);
INSERT INTO "country_hierarchy" VALUES (10,2,3,2,'Brazil',2);
INSERT INTO "country_hierarchy" VALUES (11,3,4,3,'China',2);
INSERT INTO "country_hierarchy" VALUES (12,4,5,4,'UK ',2);
INSERT INTO "country_hierarchy" VALUES (13,1,6,1,'Country 1',2);
INSERT INTO "country_hierarchy" VALUES (14,1,7,1,'Country 2',2);
INSERT INTO "country_hierarchy" VALUES (15,1,8,1,'Country 3',2);
INSERT INTO "country_hierarchy" VALUES (16,2,9,2,'Country 4',2);
INSERT INTO "country_hierarchy" VALUES (17,3,10,3,'Country 5',2);
INSERT INTO "country_hierarchy" VALUES (18,4,11,4,'Country 6',2);
INSERT INTO "country_hierarchy" VALUES (19,5,12,5,'Country 7',2);
INSERT INTO "country_hierarchy" VALUES (20,6,13,6,'Country 8',2);
CREATE TABLE "genre" (
  "idgenre" int(11) NOT NULL ,
  "name" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idgenre")
);
INSERT INTO "genre" VALUES (1,'A');
INSERT INTO "genre" VALUES (2,'B');
INSERT INTO "genre" VALUES (3,'C');
INSERT INTO "genre" VALUES (4,'D');
INSERT INTO "genre" VALUES (5,'E');
INSERT INTO "genre" VALUES (6,'F');
INSERT INTO "genre" VALUES (7,'G');
INSERT INTO "genre" VALUES (8,'H');
INSERT INTO "genre" VALUES (9,'I');
INSERT INTO "genre" VALUES (10,'J');
INSERT INTO "genre" VALUES (11,'K');
INSERT INTO "genre" VALUES (12,'L');
INSERT INTO "genre" VALUES (13,'M');
INSERT INTO "genre" VALUES (14,'N');
INSERT INTO "genre" VALUES (15,'O');
INSERT INTO "genre" VALUES (16,'P');
INSERT INTO "genre" VALUES (17,'Q');
INSERT INTO "genre" VALUES (18,'R');
INSERT INTO "genre" VALUES (19,'S');
INSERT INTO "genre" VALUES (20,'T');
INSERT INTO "genre" VALUES (21,'U');
INSERT INTO "genre" VALUES (22,'V');
INSERT INTO "genre" VALUES (23,'W');
INSERT INTO "genre" VALUES (24,'X');
INSERT INTO "genre" VALUES (25,'Y');
INSERT INTO "genre" VALUES (26,'Z');
CREATE TABLE "genre_hierarchy" (
  "idhierarchy" int(11) NOT NULL ,
  "parentId" int(11) DEFAULT NULL,
  "original_id" int(11) DEFAULT NULL,
  "origin_parent" int(11) DEFAULT NULL,
  "Label" varchar(45) DEFAULT NULL,
  "Level" int(11) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "genre_hierarchy" VALUES (1,0,1,0,'A',1);
INSERT INTO "genre_hierarchy" VALUES (2,0,2,0,'B',1);
INSERT INTO "genre_hierarchy" VALUES (3,0,3,0,'C',1);
INSERT INTO "genre_hierarchy" VALUES (4,0,4,0,'D',1);
INSERT INTO "genre_hierarchy" VALUES (5,0,5,0,'E',1);
INSERT INTO "genre_hierarchy" VALUES (6,0,6,0,'F',1);
INSERT INTO "genre_hierarchy" VALUES (8,1,1,0,'Animation',2);
INSERT INTO "genre_hierarchy" VALUES (9,1,2,0,'Adventure',2);
INSERT INTO "genre_hierarchy" VALUES (10,2,3,0,'Comedy',2);
INSERT INTO "genre_hierarchy" VALUES (11,5,4,0,'Romance',2);
INSERT INTO "genre_hierarchy" VALUES (12,3,5,0,'Drama',2);
INSERT INTO "genre_hierarchy" VALUES (13,1,6,0,'Action',2);
INSERT INTO "genre_hierarchy" VALUES (14,4,7,0,'Mystery',2);
INSERT INTO "genre_hierarchy" VALUES (15,6,8,0,'Thriller',2);
INSERT INTO "genre_hierarchy" VALUES (16,0,7,0,'G',1);
INSERT INTO "genre_hierarchy" VALUES (17,0,8,0,'H',1);
INSERT INTO "genre_hierarchy" VALUES (18,0,9,0,'I',1);
INSERT INTO "genre_hierarchy" VALUES (19,0,10,0,'J',1);
INSERT INTO "genre_hierarchy" VALUES (20,0,11,0,'K',1);
INSERT INTO "genre_hierarchy" VALUES (21,0,12,0,'L',1);
INSERT INTO "genre_hierarchy" VALUES (22,0,13,0,'M',1);
INSERT INTO "genre_hierarchy" VALUES (23,0,14,0,'N',1);
INSERT INTO "genre_hierarchy" VALUES (24,0,15,0,'O',1);
INSERT INTO "genre_hierarchy" VALUES (25,0,16,0,'P',1);
INSERT INTO "genre_hierarchy" VALUES (26,0,17,0,'Q',1);
INSERT INTO "genre_hierarchy" VALUES (27,0,18,0,'R',1);
INSERT INTO "genre_hierarchy" VALUES (28,0,19,0,'S',1);
INSERT INTO "genre_hierarchy" VALUES (29,0,20,0,'T',1);
INSERT INTO "genre_hierarchy" VALUES (30,0,21,0,'U',1);
INSERT INTO "genre_hierarchy" VALUES (31,0,22,0,'V',1);
INSERT INTO "genre_hierarchy" VALUES (32,0,23,0,'W',1);
INSERT INTO "genre_hierarchy" VALUES (33,0,24,0,'X',1);
INSERT INTO "genre_hierarchy" VALUES (34,0,25,0,'Y',1);
INSERT INTO "genre_hierarchy" VALUES (35,0,26,0,'Z',1);
INSERT INTO "genre_hierarchy" VALUES (36,1,9,1,'Sub Genre 1',2);
INSERT INTO "genre_hierarchy" VALUES (37,2,10,2,'Sub Genre 2',2);
INSERT INTO "genre_hierarchy" VALUES (38,3,11,3,'Sub Genre 3',2);
INSERT INTO "genre_hierarchy" VALUES (39,4,12,4,'Sub Genre 4',2);
INSERT INTO "genre_hierarchy" VALUES (40,5,13,5,'Sub Genre 5',2);
INSERT INTO "genre_hierarchy" VALUES (41,6,14,6,'Sub Genre 6',2);
CREATE TABLE "hierarchy" (
  "idmovie_small_hierarchy" int(11) NOT NULL,
  "name" varchar(45) DEFAULT NULL,
  "level" int(11) DEFAULT NULL,
  PRIMARY KEY ("idmovie_small_hierarchy")
);
INSERT INTO "hierarchy" VALUES (1,'genre_hierarchy',2);
INSERT INTO "hierarchy" VALUES (2,'country_hierarchy',2);
INSERT INTO "hierarchy" VALUES (3,'actor_hierarchy',2);
INSERT INTO "hierarchy" VALUES (4,'movies_genre',1);
INSERT INTO "hierarchy" VALUES (5,'movies_countries',1);
INSERT INTO "hierarchy" VALUES (6,'movies_actors',1);
CREATE TABLE "movies" (
  "idmovies" int(11) NOT NULL ,
  "moviesName" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idmovies")
);
INSERT INTO "movies" VALUES (1,'Rango');
INSERT INTO "movies" VALUES (2,'Confessions of a Shopaholic');
INSERT INTO "movies" VALUES (3,'The Tourist');
INSERT INTO "movies" VALUES (4,'Limitless');
INSERT INTO "movies" VALUES (5,'Land of the Lost');
INSERT INTO "movies" VALUES (6,'Movie 1');
INSERT INTO "movies" VALUES (7,'Movie 2');
INSERT INTO "movies" VALUES (8,'Movie 3');
INSERT INTO "movies" VALUES (9,'Movie 4');
INSERT INTO "movies" VALUES (10,'Movie 5');
CREATE TABLE "movies_actors" (
  "idmovies_actors" int(11) NOT NULL ,
  "moviesID" int(11) DEFAULT NULL,
  "actorsID" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idmovies_actors")
);
INSERT INTO "movies_actors" VALUES (1,1,32,'0.20');
INSERT INTO "movies_actors" VALUES (2,1,33,'0.20');
INSERT INTO "movies_actors" VALUES (3,2,33,'0.14');
INSERT INTO "movies_actors" VALUES (4,2,34,'0.14');
INSERT INTO "movies_actors" VALUES (5,2,35,'0.14');
INSERT INTO "movies_actors" VALUES (6,3,32,'0.25');
INSERT INTO "movies_actors" VALUES (7,3,36,'0.25');
INSERT INTO "movies_actors" VALUES (8,4,37,'0.16');
INSERT INTO "movies_actors" VALUES (9,4,38,'0.16');
INSERT INTO "movies_actors" VALUES (10,4,39,'0.16');
INSERT INTO "movies_actors" VALUES (11,5,38,'0.16');
INSERT INTO "movies_actors" VALUES (12,5,40,'0.16');
INSERT INTO "movies_actors" VALUES (13,5,41,'0.16');
INSERT INTO "movies_actors" VALUES (14,6,32,'0.20');
INSERT INTO "movies_actors" VALUES (15,6,33,'0.20');
INSERT INTO "movies_actors" VALUES (16,7,34,'0.14');
INSERT INTO "movies_actors" VALUES (17,7,35,'0.14');
INSERT INTO "movies_actors" VALUES (18,7,36,'0.14');
INSERT INTO "movies_actors" VALUES (19,7,37,'0.14');
INSERT INTO "movies_actors" VALUES (20,8,38,'0.16');
INSERT INTO "movies_actors" VALUES (21,8,39,'0.16');
INSERT INTO "movies_actors" VALUES (22,8,40,'0.16');
INSERT INTO "movies_actors" VALUES (23,9,41,'0.25');
INSERT INTO "movies_actors" VALUES (24,9,32,'0.25');
INSERT INTO "movies_actors" VALUES (25,10,32,'0.33');
INSERT INTO "movies_actors" VALUES (26,10,33,'0.33');
INSERT INTO "movies_actors" VALUES (53,1,43,'0.20');
INSERT INTO "movies_actors" VALUES (54,1,44,'0.20');
INSERT INTO "movies_actors" VALUES (55,1,45,'0.20');
INSERT INTO "movies_actors" VALUES (56,2,46,'0.14');
INSERT INTO "movies_actors" VALUES (57,2,47,'0.14');
INSERT INTO "movies_actors" VALUES (58,2,48,'0.14');
INSERT INTO "movies_actors" VALUES (59,3,49,'0.25');
INSERT INTO "movies_actors" VALUES (60,3,50,'0.25');
INSERT INTO "movies_actors" VALUES (61,4,51,'0.16');
INSERT INTO "movies_actors" VALUES (62,4,52,'0.16');
INSERT INTO "movies_actors" VALUES (63,4,43,'0.16');
INSERT INTO "movies_actors" VALUES (64,5,44,'0.16');
INSERT INTO "movies_actors" VALUES (65,5,45,'0.16');
INSERT INTO "movies_actors" VALUES (66,5,46,'0.16');
INSERT INTO "movies_actors" VALUES (67,6,47,'0.20');
INSERT INTO "movies_actors" VALUES (68,6,48,'0.20');
INSERT INTO "movies_actors" VALUES (69,6,49,'0.20');
INSERT INTO "movies_actors" VALUES (70,7,50,'0.14');
INSERT INTO "movies_actors" VALUES (71,7,51,'0.14');
INSERT INTO "movies_actors" VALUES (72,7,52,'0.14');
INSERT INTO "movies_actors" VALUES (73,8,43,'0.16');
INSERT INTO "movies_actors" VALUES (74,8,44,'0.16');
INSERT INTO "movies_actors" VALUES (75,8,45,'0.16');
INSERT INTO "movies_actors" VALUES (76,9,46,'0.25');
INSERT INTO "movies_actors" VALUES (77,9,47,'0.25');
INSERT INTO "movies_actors" VALUES (78,10,48,'0.33');
CREATE TABLE "movies_countries" (
  "idmovies_countries" int(11) NOT NULL ,
  "moviesID" int(11) DEFAULT NULL,
  "countryID" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idmovies_countries")
);
INSERT INTO "movies_countries" VALUES (1,1,8,'0.25');
INSERT INTO "movies_countries" VALUES (2,2,8,'0.25');
INSERT INTO "movies_countries" VALUES (3,2,9,'0.25');
INSERT INTO "movies_countries" VALUES (4,3,8,'0.16');
INSERT INTO "movies_countries" VALUES (5,3,10,'0.16');
INSERT INTO "movies_countries" VALUES (6,3,11,'0.16');
INSERT INTO "movies_countries" VALUES (7,3,12,'0.16');
INSERT INTO "movies_countries" VALUES (8,4,9,'0.33');
INSERT INTO "movies_countries" VALUES (9,4,8,'0.33');
INSERT INTO "movies_countries" VALUES (10,5,8,'0.33');
INSERT INTO "movies_countries" VALUES (11,5,9,'0.33');
INSERT INTO "movies_countries" VALUES (12,6,10,'0.16');
INSERT INTO "movies_countries" VALUES (13,6,11,'0.16');
INSERT INTO "movies_countries" VALUES (14,6,12,'0.16');
INSERT INTO "movies_countries" VALUES (15,6,8,'0.16');
INSERT INTO "movies_countries" VALUES (16,7,9,'0.33');
INSERT INTO "movies_countries" VALUES (17,7,10,'0.33');
INSERT INTO "movies_countries" VALUES (18,8,11,'0.33');
INSERT INTO "movies_countries" VALUES (19,8,12,'0.33');
INSERT INTO "movies_countries" VALUES (20,9,8,'0.33');
INSERT INTO "movies_countries" VALUES (21,9,9,'0.33');
INSERT INTO "movies_countries" VALUES (22,10,8,'0.33');
INSERT INTO "movies_countries" VALUES (23,10,9,'0.33');
INSERT INTO "movies_countries" VALUES (24,10,10,'0.33');
INSERT INTO "movies_countries" VALUES (25,1,13,'0.25');
INSERT INTO "movies_countries" VALUES (26,1,14,'0.25');
INSERT INTO "movies_countries" VALUES (27,1,15,'0.25');
INSERT INTO "movies_countries" VALUES (28,2,16,'0.25');
INSERT INTO "movies_countries" VALUES (29,2,17,'0.25');
INSERT INTO "movies_countries" VALUES (30,3,18,'0.16');
INSERT INTO "movies_countries" VALUES (31,3,19,'0.16');
INSERT INTO "movies_countries" VALUES (32,4,20,'0.33');
INSERT INTO "movies_countries" VALUES (33,5,17,'0.33');
INSERT INTO "movies_countries" VALUES (34,6,19,'0.16');
INSERT INTO "movies_countries" VALUES (35,6,20,'0.16');
INSERT INTO "movies_countries" VALUES (36,7,13,'0.33');
INSERT INTO "movies_countries" VALUES (37,8,14,'0.33');
INSERT INTO "movies_countries" VALUES (38,9,10,'0.33');
CREATE TABLE "movies_genre" (
  "idmovies_genre" int(11) NOT NULL ,
  "moviesID" int(11) DEFAULT NULL,
  "genresID" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idmovies_genre")
);
INSERT INTO "movies_genre" VALUES (1,1,8,'0.20');
INSERT INTO "movies_genre" VALUES (2,1,9,'0.20');
INSERT INTO "movies_genre" VALUES (3,1,10,'0.20');
INSERT INTO "movies_genre" VALUES (4,2,10,'0.33');
INSERT INTO "movies_genre" VALUES (5,2,11,'0.33');
INSERT INTO "movies_genre" VALUES (6,3,13,'0.25');
INSERT INTO "movies_genre" VALUES (7,3,12,'0.25');
INSERT INTO "movies_genre" VALUES (8,3,11,'0.25');
INSERT INTO "movies_genre" VALUES (9,4,14,'0.33');
INSERT INTO "movies_genre" VALUES (10,4,15,'0.33');
INSERT INTO "movies_genre" VALUES (11,5,9,'0.25');
INSERT INTO "movies_genre" VALUES (12,5,10,'0.25');
INSERT INTO "movies_genre" VALUES (13,5,13,'0.25');
INSERT INTO "movies_genre" VALUES (14,6,8,'0.33');
INSERT INTO "movies_genre" VALUES (15,6,9,'0.33');
INSERT INTO "movies_genre" VALUES (16,7,10,'0.33');
INSERT INTO "movies_genre" VALUES (17,7,11,'0.33');
INSERT INTO "movies_genre" VALUES (18,8,12,'0.25');
INSERT INTO "movies_genre" VALUES (19,8,13,'0.25');
INSERT INTO "movies_genre" VALUES (20,8,14,'0.25');
INSERT INTO "movies_genre" VALUES (21,9,15,'0.16');
INSERT INTO "movies_genre" VALUES (22,9,8,'0.16');
INSERT INTO "movies_genre" VALUES (23,9,9,'0.16');
INSERT INTO "movies_genre" VALUES (24,9,10,'0.16');
INSERT INTO "movies_genre" VALUES (25,9,11,'0.16');
INSERT INTO "movies_genre" VALUES (26,10,8,'0.50');
INSERT INTO "movies_genre" VALUES (27,1,36,'0.20');
INSERT INTO "movies_genre" VALUES (28,2,37,'0.33');
INSERT INTO "movies_genre" VALUES (29,3,39,'0.25');
INSERT INTO "movies_genre" VALUES (30,4,40,'0.33');
INSERT INTO "movies_genre" VALUES (31,5,41,'0.25');
INSERT INTO "movies_genre" VALUES (32,6,36,'0.33');
INSERT INTO "movies_genre" VALUES (33,7,37,'0.33');
INSERT INTO "movies_genre" VALUES (34,8,39,'0.25');
INSERT INTO "movies_genre" VALUES (35,9,36,'0.16');
INSERT INTO "movies_genre" VALUES (36,10,40,'0.50');
INSERT INTO "movies_genre" VALUES (37,1,41,'0.20');
CREATE TABLE "movies_linking" (
  "idhierarchy" int(11) DEFAULT NULL,
  "name" varchar(45) DEFAULT NULL,
  "columnName" varchar(45) DEFAULT NULL
);
INSERT INTO "movies_linking" VALUES (1,'movies_genre','genresID');
INSERT INTO "movies_linking" VALUES (2,'movies_countries','countryID');
INSERT INTO "movies_linking" VALUES (3,'movies_actors','actorsID');
CREATE TABLE "people_actors" (
  "idmovies_actors" int(11) NOT NULL ,
  "peopleID" int(11) DEFAULT NULL,
  "actorsID" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idmovies_actors")
);
INSERT INTO "people_actors" VALUES (1,1,52,'0.20');
INSERT INTO "people_actors" VALUES (2,1,51,'0.20');
INSERT INTO "people_actors" VALUES (3,2,42,'0.14');
INSERT INTO "people_actors" VALUES (4,2,43,'0.14');
INSERT INTO "people_actors" VALUES (5,2,45,'0.14');
INSERT INTO "people_actors" VALUES (6,3,49,'0.25');
INSERT INTO "people_actors" VALUES (7,3,50,'0.25');
INSERT INTO "people_actors" VALUES (8,4,34,'0.16');
INSERT INTO "people_actors" VALUES (9,4,35,'0.16');
INSERT INTO "people_actors" VALUES (10,4,36,'0.16');
INSERT INTO "people_actors" VALUES (11,5,40,'0.16');
INSERT INTO "people_actors" VALUES (12,5,41,'0.16');
INSERT INTO "people_actors" VALUES (13,5,41,'0.16');
INSERT INTO "people_actors" VALUES (14,6,42,'0.20');
INSERT INTO "people_actors" VALUES (15,6,52,'0.20');
INSERT INTO "people_actors" VALUES (16,7,34,'0.14');
INSERT INTO "people_actors" VALUES (17,7,35,'0.14');
INSERT INTO "people_actors" VALUES (18,7,36,'0.14');
INSERT INTO "people_actors" VALUES (19,7,52,'0.14');
INSERT INTO "people_actors" VALUES (20,8,41,'0.16');
INSERT INTO "people_actors" VALUES (21,8,42,'0.16');
INSERT INTO "people_actors" VALUES (22,8,43,'0.16');
INSERT INTO "people_actors" VALUES (23,9,50,'0.25');
INSERT INTO "people_actors" VALUES (24,9,50,'0.25');
INSERT INTO "people_actors" VALUES (25,10,35,'0.33');
INSERT INTO "people_actors" VALUES (26,10,36,'0.33');
INSERT INTO "people_actors" VALUES (53,1,50,'0.20');
INSERT INTO "people_actors" VALUES (54,1,40,'0.20');
INSERT INTO "people_actors" VALUES (55,1,41,'0.20');
INSERT INTO "people_actors" VALUES (56,2,46,'0.14');
INSERT INTO "people_actors" VALUES (57,2,47,'0.14');
INSERT INTO "people_actors" VALUES (58,2,48,'0.14');
INSERT INTO "people_actors" VALUES (59,3,32,'0.25');
INSERT INTO "people_actors" VALUES (60,3,33,'0.25');
INSERT INTO "people_actors" VALUES (61,4,37,'0.16');
INSERT INTO "people_actors" VALUES (62,4,38,'0.16');
INSERT INTO "people_actors" VALUES (63,4,39,'0.16');
INSERT INTO "people_actors" VALUES (64,5,51,'0.16');
INSERT INTO "people_actors" VALUES (65,5,52,'0.16');
INSERT INTO "people_actors" VALUES (66,5,32,'0.16');
INSERT INTO "people_actors" VALUES (67,6,51,'0.20');
INSERT INTO "people_actors" VALUES (68,6,50,'0.20');
INSERT INTO "people_actors" VALUES (69,6,33,'0.20');
INSERT INTO "people_actors" VALUES (70,7,51,'0.14');
INSERT INTO "people_actors" VALUES (71,7,50,'0.14');
INSERT INTO "people_actors" VALUES (72,7,40,'0.14');
INSERT INTO "people_actors" VALUES (73,8,44,'0.16');
INSERT INTO "people_actors" VALUES (74,8,45,'0.16');
INSERT INTO "people_actors" VALUES (75,8,32,'0.16');
INSERT INTO "people_actors" VALUES (76,9,54,'0.25');
INSERT INTO "people_actors" VALUES (77,9,52,'0.25');
INSERT INTO "people_actors" VALUES (78,10,37,'0.33');
CREATE TABLE "people_countries" (
  "idmovies_countries" int(11) NOT NULL ,
  "peopleID" int(11) DEFAULT NULL,
  "countryID" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idmovies_countries")
);
INSERT INTO "people_countries" VALUES (1,1,20,'0.25');
INSERT INTO "people_countries" VALUES (2,2,16,'0.25');
INSERT INTO "people_countries" VALUES (3,2,18,'0.25');
INSERT INTO "people_countries" VALUES (4,3,11,'0.16');
INSERT INTO "people_countries" VALUES (5,3,12,'0.16');
INSERT INTO "people_countries" VALUES (6,3,20,'0.16');
INSERT INTO "people_countries" VALUES (7,3,15,'0.16');
INSERT INTO "people_countries" VALUES (8,4,12,'0.33');
INSERT INTO "people_countries" VALUES (9,4,13,'0.33');
INSERT INTO "people_countries" VALUES (10,5,15,'0.33');
INSERT INTO "people_countries" VALUES (11,5,12,'0.33');
INSERT INTO "people_countries" VALUES (12,6,14,'0.16');
INSERT INTO "people_countries" VALUES (13,6,16,'0.16');
INSERT INTO "people_countries" VALUES (14,6,17,'0.16');
INSERT INTO "people_countries" VALUES (15,6,18,'0.16');
INSERT INTO "people_countries" VALUES (16,7,20,'0.33');
INSERT INTO "people_countries" VALUES (17,7,10,'0.33');
INSERT INTO "people_countries" VALUES (18,8,12,'0.33');
INSERT INTO "people_countries" VALUES (19,8,20,'0.33');
INSERT INTO "people_countries" VALUES (20,9,23,'0.33');
INSERT INTO "people_countries" VALUES (21,9,25,'0.33');
INSERT INTO "people_countries" VALUES (22,10,11,'0.33');
INSERT INTO "people_countries" VALUES (23,10,12,'0.33');
INSERT INTO "people_countries" VALUES (24,10,20,'0.33');
INSERT INTO "people_countries" VALUES (25,1,19,'0.25');
INSERT INTO "people_countries" VALUES (26,1,18,'0.25');
INSERT INTO "people_countries" VALUES (27,1,17,'0.25');
INSERT INTO "people_countries" VALUES (28,2,9,'0.25');
INSERT INTO "people_countries" VALUES (29,2,10,'0.25');
INSERT INTO "people_countries" VALUES (30,3,16,'0.16');
INSERT INTO "people_countries" VALUES (31,3,17,'0.16');
INSERT INTO "people_countries" VALUES (32,4,14,'0.33');
INSERT INTO "people_countries" VALUES (33,5,20,'0.33');
INSERT INTO "people_countries" VALUES (34,6,19,'0.16');
INSERT INTO "people_countries" VALUES (35,6,9,'0.16');
INSERT INTO "people_countries" VALUES (36,7,11,'0.33');
INSERT INTO "people_countries" VALUES (37,8,21,'0.33');
INSERT INTO "people_countries" VALUES (38,9,24,'0.33');
CREATE TABLE "people_genre" (
  "idmovies_genre" int(11) NOT NULL ,
  "peopleID" int(11) DEFAULT NULL,
  "genresID" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idmovies_genre")
);
INSERT INTO "people_genre" VALUES (1,1,41,'0.20');
INSERT INTO "people_genre" VALUES (2,1,40,'0.20');
INSERT INTO "people_genre" VALUES (3,1,39,'0.20');
INSERT INTO "people_genre" VALUES (4,2,41,'0.33');
INSERT INTO "people_genre" VALUES (5,2,42,'0.33');
INSERT INTO "people_genre" VALUES (6,3,11,'0.25');
INSERT INTO "people_genre" VALUES (7,3,12,'0.25');
INSERT INTO "people_genre" VALUES (8,3,41,'0.25');
INSERT INTO "people_genre" VALUES (9,4,15,'0.33');
INSERT INTO "people_genre" VALUES (10,4,39,'0.33');
INSERT INTO "people_genre" VALUES (11,5,41,'0.25');
INSERT INTO "people_genre" VALUES (12,5,36,'0.25');
INSERT INTO "people_genre" VALUES (13,5,37,'0.25');
INSERT INTO "people_genre" VALUES (14,6,42,'0.33');
INSERT INTO "people_genre" VALUES (15,6,10,'0.33');
INSERT INTO "people_genre" VALUES (16,7,12,'0.33');
INSERT INTO "people_genre" VALUES (17,7,41,'0.33');
INSERT INTO "people_genre" VALUES (18,8,36,'0.25');
INSERT INTO "people_genre" VALUES (19,8,37,'0.25');
INSERT INTO "people_genre" VALUES (20,8,39,'0.25');
INSERT INTO "people_genre" VALUES (21,9,41,'0.16');
INSERT INTO "people_genre" VALUES (22,9,39,'0.16');
INSERT INTO "people_genre" VALUES (23,9,11,'0.16');
INSERT INTO "people_genre" VALUES (24,9,42,'0.16');
INSERT INTO "people_genre" VALUES (25,9,10,'0.16');
INSERT INTO "people_genre" VALUES (26,10,12,'0.50');
INSERT INTO "people_genre" VALUES (27,1,36,'0.20');
INSERT INTO "people_genre" VALUES (28,2,10,'0.33');
INSERT INTO "people_genre" VALUES (29,3,14,'0.25');
INSERT INTO "people_genre" VALUES (30,4,40,'0.33');
INSERT INTO "people_genre" VALUES (31,5,41,'0.25');
INSERT INTO "people_genre" VALUES (32,6,11,'0.33');
INSERT INTO "people_genre" VALUES (33,7,14,'0.33');
INSERT INTO "people_genre" VALUES (34,8,40,'0.25');
INSERT INTO "people_genre" VALUES (35,9,11,'0.16');
INSERT INTO "people_genre" VALUES (36,10,41,'0.50');
INSERT INTO "people_genre" VALUES (37,1,37,'0.20');
CREATE TABLE "people_linking" (
  "idhierarchy" int(11) NOT NULL DEFAULT '0',
  "name" varchar(45) DEFAULT NULL,
  "columnName" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "people_linking" VALUES (1,'people_genre','genresID');
INSERT INTO "people_linking" VALUES (2,'people_countries','countryID');
INSERT INTO "people_linking" VALUES (3,'people_actors','actorsID');
CREATE TABLE "sub_genre" (
  "idgenre" int(11) NOT NULL ,
  "genreName" varchar(45) DEFAULT NULL,
  "parentID" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idgenre")
);
INSERT INTO "sub_genre" VALUES (1,'Animation','1');
INSERT INTO "sub_genre" VALUES (2,'Adventure','1');
INSERT INTO "sub_genre" VALUES (3,'Comedy','2');
INSERT INTO "sub_genre" VALUES (4,'Romance','5');
INSERT INTO "sub_genre" VALUES (5,'Drama','3');
INSERT INTO "sub_genre" VALUES (6,'Action','1');
INSERT INTO "sub_genre" VALUES (7,'Mystery','4');
INSERT INTO "sub_genre" VALUES (8,'Thriller','6');
INSERT INTO "sub_genre" VALUES (9,'Sub Genre 1','1');
INSERT INTO "sub_genre" VALUES (10,'Sub Genre 2','2');
INSERT INTO "sub_genre" VALUES (11,'Sub Genre 3','3');
INSERT INTO "sub_genre" VALUES (12,'Sub Genre 4','4');
INSERT INTO "sub_genre" VALUES (13,'Sub Genre 5','5');
INSERT INTO "sub_genre" VALUES (14,'Sub Genre 6','6');
CREATE TABLE "tmptable" (
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  "parentid" int(11) DEFAULT NULL
);
INSERT INTO "tmptable" VALUES ('0.20',9);
INSERT INTO "tmptable" VALUES ('0.25',9);
INSERT INTO "tmptable" VALUES ('0.20',9);
INSERT INTO "tmptable" VALUES ('0.25',9);
INSERT INTO "tmptable" VALUES ('0.33',9);
INSERT INTO "tmptable" VALUES ('0.20',8);
INSERT INTO "tmptable" VALUES ('0.14',8);
INSERT INTO "tmptable" VALUES ('0.20',8);
INSERT INTO "tmptable" VALUES ('0.33',8);
INSERT INTO "tmptable" VALUES ('0.14',7);
INSERT INTO "tmptable" VALUES ('0.14',7);
INSERT INTO "tmptable" VALUES ('0.14',10);
INSERT INTO "tmptable" VALUES ('0.14',10);
INSERT INTO "tmptable" VALUES ('0.25',1);
INSERT INTO "tmptable" VALUES ('0.14',1);
INSERT INTO "tmptable" VALUES ('0.16',2);
INSERT INTO "tmptable" VALUES ('0.14',2);
INSERT INTO "tmptable" VALUES ('0.16',1);
INSERT INTO "tmptable" VALUES ('0.16',1);
INSERT INTO "tmptable" VALUES ('0.16',1);
INSERT INTO "tmptable" VALUES ('0.16',1);
INSERT INTO "tmptable" VALUES ('0.16',1);
INSERT INTO "tmptable" VALUES ('0.16',22);
INSERT INTO "tmptable" VALUES ('0.16',22);
INSERT INTO "tmptable" VALUES ('0.16',4);
INSERT INTO "tmptable" VALUES ('0.25',4);
INSERT INTO "tmptable" VALUES ('0.20',1);
INSERT INTO "tmptable" VALUES ('0.16',1);
INSERT INTO "tmptable" VALUES ('0.16',1);
INSERT INTO "tmptable" VALUES ('0.20',2);
INSERT INTO "tmptable" VALUES ('0.16',2);
INSERT INTO "tmptable" VALUES ('0.16',2);
INSERT INTO "tmptable" VALUES ('0.20',3);
INSERT INTO "tmptable" VALUES ('0.16',3);
INSERT INTO "tmptable" VALUES ('0.16',3);
INSERT INTO "tmptable" VALUES ('0.14',4);
INSERT INTO "tmptable" VALUES ('0.16',4);
INSERT INTO "tmptable" VALUES ('0.25',4);
INSERT INTO "tmptable" VALUES ('0.14',5);
INSERT INTO "tmptable" VALUES ('0.20',5);
INSERT INTO "tmptable" VALUES ('0.25',5);
INSERT INTO "tmptable" VALUES ('0.14',6);
INSERT INTO "tmptable" VALUES ('0.20',6);
INSERT INTO "tmptable" VALUES ('0.33',6);
INSERT INTO "tmptable" VALUES ('0.25',7);
INSERT INTO "tmptable" VALUES ('0.20',7);
INSERT INTO "tmptable" VALUES ('0.25',8);
INSERT INTO "tmptable" VALUES ('0.14',8);
INSERT INTO "tmptable" VALUES ('0.16',9);
INSERT INTO "tmptable" VALUES ('0.14',9);
INSERT INTO "tmptable" VALUES ('0.16',10);
INSERT INTO "tmptable" VALUES ('0.14',10);
CREATE INDEX "movies_actors_moviesID" ON "movies_actors" ("moviesID");
CREATE INDEX "movies_actors_actorsID" ON "movies_actors" ("actorsID");
CREATE INDEX "movies_genre_moviesID" ON "movies_genre" ("moviesID");
CREATE INDEX "movies_genre_genreID" ON "movies_genre" ("genresID");
CREATE INDEX "people_actors_actorsID" ON "people_actors" ("actorsID");
CREATE INDEX "people_actors_moviesID" ON "people_actors" ("peopleID");
CREATE INDEX "movies_countries_moviesID" ON "movies_countries" ("moviesID");
CREATE INDEX "movies_countries_languagesID" ON "movies_countries" ("countryID");
CREATE INDEX "people_genre_genreID" ON "people_genre" ("genresID");
CREATE INDEX "people_genre_moviesID" ON "people_genre" ("peopleID");
CREATE INDEX "people_countries_languagesID" ON "people_countries" ("countryID");
CREATE INDEX "people_countries_moviesID" ON "people_countries" ("peopleID");
END TRANSACTION;
