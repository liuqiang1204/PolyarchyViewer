PRAGMA synchronous = OFF;
PRAGMA journal_mode = MEMORY;
BEGIN TRANSACTION;
CREATE TABLE "atom" (
  "displayName" varchar(45) NOT NULL DEFAULT '',
  "name" varchar(45) DEFAULT NULL,
  "columnName" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("displayName")
);
INSERT INTO "atom" VALUES ('People','people_linking','peopleID');
INSERT INTO "atom" VALUES ('Publications','publications_linking','publicationid');
CREATE TABLE "departments" (
  "iddepartments" int(11) NOT NULL,
  "name" varchar(45) DEFAULT NULL,
  "idfacultys" int(11) DEFAULT NULL,
  PRIMARY KEY ("iddepartments")
);
INSERT INTO "departments" VALUES (1,'Department of IT',1);
INSERT INTO "departments" VALUES (2,'Department of IT 2',1);
INSERT INTO "departments" VALUES (3,'Department of Science',2);
INSERT INTO "departments" VALUES (4,'Department of Science 2',2);
INSERT INTO "departments" VALUES (5,'Department of Business',3);
INSERT INTO "departments" VALUES (6,'Department of Business 2',3);
INSERT INTO "departments" VALUES (7,'Department of Medicine',4);
CREATE TABLE "facultys" (
  "idfacultys" int(11) NOT NULL,
  "name" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idfacultys")
);
INSERT INTO "facultys" VALUES (1,'Faculty of IT');
INSERT INTO "facultys" VALUES (2,'Faculty of Science');
INSERT INTO "facultys" VALUES (3,'Faculty of Business');
INSERT INTO "facultys" VALUES (4,'Faculty of Medicine');
CREATE TABLE "forcodes" (
  "idforcodes" int(11) NOT NULL,
  "name" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idforcodes")
);
INSERT INTO "forcodes" VALUES (1,'10000');
INSERT INTO "forcodes" VALUES (2,'20000');
INSERT INTO "forcodes" VALUES (3,'30000');
INSERT INTO "forcodes" VALUES (4,'40000');
CREATE TABLE "forcodes_hierarchy" (
  "idhierarchy" int(11) NOT NULL ,
  "parentid" int(11) DEFAULT NULL,
  "Level" int(11) DEFAULT NULL,
  "original_id" int(11) DEFAULT NULL,
  "origin_parent" int(11) DEFAULT NULL,
  "Label" varchar(95) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "forcodes_hierarchy" VALUES (1,0,1,1,0,'10000');
INSERT INTO "forcodes_hierarchy" VALUES (2,0,1,2,0,'20000');
INSERT INTO "forcodes_hierarchy" VALUES (3,0,1,3,0,'30000');
INSERT INTO "forcodes_hierarchy" VALUES (4,0,1,4,0,'40000');
INSERT INTO "forcodes_hierarchy" VALUES (8,1,2,1,1,'11000');
INSERT INTO "forcodes_hierarchy" VALUES (9,2,2,2,2,'21000');
INSERT INTO "forcodes_hierarchy" VALUES (10,3,2,3,3,'31000');
INSERT INTO "forcodes_hierarchy" VALUES (11,4,2,4,4,'41000');
INSERT INTO "forcodes_hierarchy" VALUES (12,4,2,5,4,'42000');
INSERT INTO "forcodes_hierarchy" VALUES (15,8,3,1,1,'11001');
INSERT INTO "forcodes_hierarchy" VALUES (16,9,3,2,2,'21001');
INSERT INTO "forcodes_hierarchy" VALUES (17,10,3,3,3,'31001');
INSERT INTO "forcodes_hierarchy" VALUES (18,11,3,4,3,'31002');
INSERT INTO "forcodes_hierarchy" VALUES (19,12,3,5,4,'41001');
INSERT INTO "forcodes_hierarchy" VALUES (20,8,3,6,1,'12001');
INSERT INTO "forcodes_hierarchy" VALUES (21,9,3,7,2,'22001');
INSERT INTO "forcodes_hierarchy" VALUES (22,10,3,8,3,'32001');
INSERT INTO "forcodes_hierarchy" VALUES (23,11,3,9,4,'42001');
INSERT INTO "forcodes_hierarchy" VALUES (24,12,3,10,5,'52001');
CREATE TABLE "forcodes_level2" (
  "idforcodes_level2" int(11) NOT NULL,
  "name" varchar(45) DEFAULT NULL,
  "parentid" int(11) DEFAULT NULL,
  PRIMARY KEY ("idforcodes_level2")
);
INSERT INTO "forcodes_level2" VALUES (1,'11000',1);
INSERT INTO "forcodes_level2" VALUES (2,'21000',2);
INSERT INTO "forcodes_level2" VALUES (3,'31000',3);
INSERT INTO "forcodes_level2" VALUES (4,'41000',4);
INSERT INTO "forcodes_level2" VALUES (5,'42000',4);
CREATE TABLE "forcodes_level3" (
  "idforcodes_level3" int(11) NOT NULL,
  "name" varchar(45) DEFAULT NULL,
  "parentid" int(11) DEFAULT NULL,
  PRIMARY KEY ("idforcodes_level3")
);
INSERT INTO "forcodes_level3" VALUES (1,'11001',1);
INSERT INTO "forcodes_level3" VALUES (2,'21001',2);
INSERT INTO "forcodes_level3" VALUES (3,'31001',3);
INSERT INTO "forcodes_level3" VALUES (4,'31002',3);
INSERT INTO "forcodes_level3" VALUES (5,'41001',4);
INSERT INTO "forcodes_level3" VALUES (6,'12001',1);
INSERT INTO "forcodes_level3" VALUES (7,'22001',2);
INSERT INTO "forcodes_level3" VALUES (8,'32001',3);
INSERT INTO "forcodes_level3" VALUES (9,'42001',4);
INSERT INTO "forcodes_level3" VALUES (10,'52001',5);
CREATE TABLE "hierarchy" (
  "idhierarchy" int(11) NOT NULL,
  "name" varchar(45) DEFAULT NULL,
  "level" int(11) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "hierarchy" VALUES (1,'forcodes_hierarchy',3);
INSERT INTO "hierarchy" VALUES (2,'staff_hierarchy',3);
INSERT INTO "hierarchy" VALUES (3,'theme_hierarchy',1);
CREATE TABLE "people_forcodes" (
  "idpublications_forcodes" int(11) NOT NULL ,
  "peopleID" int(11) DEFAULT NULL,
  "forcodeid" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idpublications_forcodes")
);
INSERT INTO "people_forcodes" VALUES (1,1,24,'0.50');
INSERT INTO "people_forcodes" VALUES (2,1,23,'0.50');
INSERT INTO "people_forcodes" VALUES (3,2,22,'1.00');
INSERT INTO "people_forcodes" VALUES (4,3,21,'0.33');
INSERT INTO "people_forcodes" VALUES (5,3,20,'0.33');
INSERT INTO "people_forcodes" VALUES (6,3,19,'0.33');
INSERT INTO "people_forcodes" VALUES (7,4,18,'0.50');
INSERT INTO "people_forcodes" VALUES (8,4,24,'0.50');
INSERT INTO "people_forcodes" VALUES (9,5,23,'0.50');
INSERT INTO "people_forcodes" VALUES (10,5,22,'0.50');
INSERT INTO "people_forcodes" VALUES (11,6,21,'0.50');
INSERT INTO "people_forcodes" VALUES (12,6,20,'0.50');
INSERT INTO "people_forcodes" VALUES (13,7,19,'0.33');
INSERT INTO "people_forcodes" VALUES (14,7,15,'0.33');
INSERT INTO "people_forcodes" VALUES (15,7,24,'0.33');
INSERT INTO "people_forcodes" VALUES (16,8,23,'0.33');
INSERT INTO "people_forcodes" VALUES (17,8,21,'0.33');
INSERT INTO "people_forcodes" VALUES (18,8,20,'0.33');
INSERT INTO "people_forcodes" VALUES (19,9,19,'0.33');
INSERT INTO "people_forcodes" VALUES (20,9,18,'0.33');
INSERT INTO "people_forcodes" VALUES (21,9,17,'0.33');
INSERT INTO "people_forcodes" VALUES (22,10,16,'1.00');
INSERT INTO "people_forcodes" VALUES (23,11,15,'1.00');
INSERT INTO "people_forcodes" VALUES (24,12,15,'0.50');
INSERT INTO "people_forcodes" VALUES (25,12,16,'0.50');
INSERT INTO "people_forcodes" VALUES (26,13,17,'0.33');
INSERT INTO "people_forcodes" VALUES (27,13,18,'0.33');
INSERT INTO "people_forcodes" VALUES (28,13,19,'0.30');
INSERT INTO "people_forcodes" VALUES (29,14,24,'1.00');
INSERT INTO "people_forcodes" VALUES (30,15,23,'1.00');
CREATE TABLE "people_linking" (
  "idhierarchy" int(11) NOT NULL DEFAULT '0',
  "name" varchar(45) DEFAULT NULL,
  "columnName" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "people_linking" VALUES (1,'people_forcodes','forcodeID');
INSERT INTO "people_linking" VALUES (2,'people_researchers','researcherID');
INSERT INTO "people_linking" VALUES (3,'people_theme','themeID');
CREATE TABLE "people_researchers" (
  "idpublications_researchers" int(11) NOT NULL ,
  "peopleID" int(11) DEFAULT NULL,
  "researcherid" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idpublications_researchers")
);
INSERT INTO "people_researchers" VALUES (1,1,25,'0.33');
INSERT INTO "people_researchers" VALUES (2,1,24,'0.33');
INSERT INTO "people_researchers" VALUES (3,1,23,'0.33');
INSERT INTO "people_researchers" VALUES (4,2,15,'0.50');
INSERT INTO "people_researchers" VALUES (5,2,16,'0.50');
INSERT INTO "people_researchers" VALUES (6,3,25,'1.00');
INSERT INTO "people_researchers" VALUES (7,4,24,'0.50');
INSERT INTO "people_researchers" VALUES (8,4,23,'0.50');
INSERT INTO "people_researchers" VALUES (9,5,16,'0.33');
INSERT INTO "people_researchers" VALUES (10,5,17,'0.33');
INSERT INTO "people_researchers" VALUES (11,5,25,'0.33');
INSERT INTO "people_researchers" VALUES (12,6,24,'0.33');
INSERT INTO "people_researchers" VALUES (13,6,23,'0.33');
INSERT INTO "people_researchers" VALUES (14,6,17,'0.33');
INSERT INTO "people_researchers" VALUES (15,7,16,'0.33');
INSERT INTO "people_researchers" VALUES (16,7,17,'0.33');
INSERT INTO "people_researchers" VALUES (17,7,18,'0.33');
INSERT INTO "people_researchers" VALUES (18,8,19,'0.33');
INSERT INTO "people_researchers" VALUES (19,8,20,'0.33');
INSERT INTO "people_researchers" VALUES (20,8,21,'0.33');
INSERT INTO "people_researchers" VALUES (21,9,22,'0.20');
INSERT INTO "people_researchers" VALUES (22,9,23,'0.20');
INSERT INTO "people_researchers" VALUES (23,9,24,'0.20');
INSERT INTO "people_researchers" VALUES (24,9,25,'0.20');
INSERT INTO "people_researchers" VALUES (25,9,19,'0.20');
INSERT INTO "people_researchers" VALUES (26,10,24,'0.50');
INSERT INTO "people_researchers" VALUES (27,10,23,'0.50');
INSERT INTO "people_researchers" VALUES (28,11,15,'1.00');
INSERT INTO "people_researchers" VALUES (29,12,25,'1.00');
INSERT INTO "people_researchers" VALUES (30,13,24,'0.50');
INSERT INTO "people_researchers" VALUES (31,13,23,'0.50');
INSERT INTO "people_researchers" VALUES (32,14,15,'0.50');
INSERT INTO "people_researchers" VALUES (33,14,25,'0.50');
INSERT INTO "people_researchers" VALUES (34,15,24,'0.25');
INSERT INTO "people_researchers" VALUES (35,15,19,'0.25');
INSERT INTO "people_researchers" VALUES (36,15,23,'0.25');
INSERT INTO "people_researchers" VALUES (37,15,22,'0.25');
CREATE TABLE "people_theme" (
  "idpublications_theme" int(11) NOT NULL ,
  "peopleID" int(11) DEFAULT NULL,
  "themeid" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idpublications_theme")
);
INSERT INTO "people_theme" VALUES (1,1,4,'0.50');
INSERT INTO "people_theme" VALUES (2,1,3,'0.50');
INSERT INTO "people_theme" VALUES (3,2,4,'1.00');
INSERT INTO "people_theme" VALUES (4,3,3,'0.33');
INSERT INTO "people_theme" VALUES (5,3,4,'0.33');
INSERT INTO "people_theme" VALUES (6,3,3,'0.33');
INSERT INTO "people_theme" VALUES (7,4,2,'1.00');
INSERT INTO "people_theme" VALUES (8,5,4,'0.50');
INSERT INTO "people_theme" VALUES (9,5,3,'0.50');
INSERT INTO "people_theme" VALUES (10,6,2,'0.50');
INSERT INTO "people_theme" VALUES (11,6,1,'0.50');
INSERT INTO "people_theme" VALUES (12,7,2,'0.50');
INSERT INTO "people_theme" VALUES (13,7,4,'0.50');
INSERT INTO "people_theme" VALUES (14,8,3,'0.50');
INSERT INTO "people_theme" VALUES (15,8,2,'0.50');
INSERT INTO "people_theme" VALUES (16,9,4,'0.33');
INSERT INTO "people_theme" VALUES (17,9,3,'0.33');
INSERT INTO "people_theme" VALUES (18,9,4,'0.33');
INSERT INTO "people_theme" VALUES (21,10,4,'1.00');
INSERT INTO "people_theme" VALUES (22,11,4,'0.50');
INSERT INTO "people_theme" VALUES (23,11,3,'0.50');
INSERT INTO "people_theme" VALUES (24,12,4,'0.50');
INSERT INTO "people_theme" VALUES (25,12,2,'0.50');
INSERT INTO "people_theme" VALUES (26,13,4,'0.33');
INSERT INTO "people_theme" VALUES (27,13,3,'0.33');
INSERT INTO "people_theme" VALUES (28,13,2,'0.33');
INSERT INTO "people_theme" VALUES (29,14,4,'0.33');
INSERT INTO "people_theme" VALUES (30,14,1,'0.33');
INSERT INTO "people_theme" VALUES (31,14,2,'0.33');
INSERT INTO "people_theme" VALUES (32,15,4,'0.50');
INSERT INTO "people_theme" VALUES (33,15,1,'0.50');
CREATE TABLE "publications" (
  "idpublications" int(11) NOT NULL,
  "name" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idpublications")
);
INSERT INTO "publications" VALUES (1,'Paper 1');
INSERT INTO "publications" VALUES (2,'Paper 2');
INSERT INTO "publications" VALUES (3,'Paper 3');
INSERT INTO "publications" VALUES (4,'Paper 4');
INSERT INTO "publications" VALUES (5,'Paper 5');
INSERT INTO "publications" VALUES (6,'Programming 1');
INSERT INTO "publications" VALUES (7,'Programming 2');
INSERT INTO "publications" VALUES (8,'Programming 3');
INSERT INTO "publications" VALUES (9,'Programming 4');
INSERT INTO "publications" VALUES (10,'Programming 5');
INSERT INTO "publications" VALUES (11,'Database 1');
INSERT INTO "publications" VALUES (12,'Database 2');
INSERT INTO "publications" VALUES (13,'Database 3');
INSERT INTO "publications" VALUES (14,'Database 4');
INSERT INTO "publications" VALUES (15,'Database 15');
CREATE TABLE "publications_forcodes" (
  "idpublications_forcodes" int(11) NOT NULL ,
  "publicationid" int(11) DEFAULT NULL,
  "forcodeid" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idpublications_forcodes")
);
INSERT INTO "publications_forcodes" VALUES (1,1,15,'0.50');
INSERT INTO "publications_forcodes" VALUES (2,1,16,'0.50');
INSERT INTO "publications_forcodes" VALUES (3,2,17,'1.00');
INSERT INTO "publications_forcodes" VALUES (4,3,18,'0.33');
INSERT INTO "publications_forcodes" VALUES (5,3,19,'0.33');
INSERT INTO "publications_forcodes" VALUES (6,3,15,'0.33');
INSERT INTO "publications_forcodes" VALUES (7,4,16,'0.50');
INSERT INTO "publications_forcodes" VALUES (8,4,17,'0.50');
INSERT INTO "publications_forcodes" VALUES (9,5,18,'0.50');
INSERT INTO "publications_forcodes" VALUES (10,5,19,'0.50');
INSERT INTO "publications_forcodes" VALUES (11,6,20,'0.50');
INSERT INTO "publications_forcodes" VALUES (12,6,21,'0.50');
INSERT INTO "publications_forcodes" VALUES (13,7,22,'0.33');
INSERT INTO "publications_forcodes" VALUES (14,7,23,'0.33');
INSERT INTO "publications_forcodes" VALUES (15,7,24,'0.33');
INSERT INTO "publications_forcodes" VALUES (16,8,15,'0.33');
INSERT INTO "publications_forcodes" VALUES (17,8,16,'0.33');
INSERT INTO "publications_forcodes" VALUES (18,8,17,'0.33');
INSERT INTO "publications_forcodes" VALUES (19,9,18,'0.33');
INSERT INTO "publications_forcodes" VALUES (20,9,19,'0.33');
INSERT INTO "publications_forcodes" VALUES (21,9,20,'0.33');
INSERT INTO "publications_forcodes" VALUES (22,10,21,'1.00');
INSERT INTO "publications_forcodes" VALUES (23,11,22,'1.00');
INSERT INTO "publications_forcodes" VALUES (24,12,23,'0.50');
INSERT INTO "publications_forcodes" VALUES (25,12,24,'0.50');
INSERT INTO "publications_forcodes" VALUES (26,13,15,'0.33');
INSERT INTO "publications_forcodes" VALUES (27,13,16,'0.33');
INSERT INTO "publications_forcodes" VALUES (28,13,17,'0.30');
INSERT INTO "publications_forcodes" VALUES (29,14,15,'1.00');
INSERT INTO "publications_forcodes" VALUES (30,15,16,'1.00');
CREATE TABLE "publications_linking" (
  "idhierarchy" int(11) NOT NULL DEFAULT '0',
  "name" varchar(45) DEFAULT NULL,
  "columnName" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "publications_linking" VALUES (1,'publications_forcodes','forcodeID');
INSERT INTO "publications_linking" VALUES (2,'publications_researchers','researcherID');
INSERT INTO "publications_linking" VALUES (3,'publications_theme','themeID');
CREATE TABLE "publications_researchers" (
  "idpublications_researchers" int(11) NOT NULL ,
  "publicationid" int(11) DEFAULT NULL,
  "researcherid" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idpublications_researchers")
);
INSERT INTO "publications_researchers" VALUES (1,1,15,'0.33');
INSERT INTO "publications_researchers" VALUES (2,1,16,'0.33');
INSERT INTO "publications_researchers" VALUES (3,1,17,'0.33');
INSERT INTO "publications_researchers" VALUES (4,2,18,'0.50');
INSERT INTO "publications_researchers" VALUES (5,2,19,'0.50');
INSERT INTO "publications_researchers" VALUES (6,3,20,'1.00');
INSERT INTO "publications_researchers" VALUES (7,4,21,'0.50');
INSERT INTO "publications_researchers" VALUES (8,4,22,'0.50');
INSERT INTO "publications_researchers" VALUES (9,5,15,'0.33');
INSERT INTO "publications_researchers" VALUES (10,5,18,'0.33');
INSERT INTO "publications_researchers" VALUES (11,5,21,'0.33');
INSERT INTO "publications_researchers" VALUES (12,6,15,'0.33');
INSERT INTO "publications_researchers" VALUES (13,6,16,'0.33');
INSERT INTO "publications_researchers" VALUES (14,6,17,'0.33');
INSERT INTO "publications_researchers" VALUES (15,7,15,'0.33');
INSERT INTO "publications_researchers" VALUES (16,7,16,'0.33');
INSERT INTO "publications_researchers" VALUES (17,7,17,'0.33');
INSERT INTO "publications_researchers" VALUES (18,8,18,'0.33');
INSERT INTO "publications_researchers" VALUES (19,8,19,'0.33');
INSERT INTO "publications_researchers" VALUES (20,8,20,'0.33');
INSERT INTO "publications_researchers" VALUES (21,9,21,'0.20');
INSERT INTO "publications_researchers" VALUES (22,9,22,'0.20');
INSERT INTO "publications_researchers" VALUES (23,9,23,'0.20');
INSERT INTO "publications_researchers" VALUES (24,9,24,'0.20');
INSERT INTO "publications_researchers" VALUES (25,9,25,'0.20');
INSERT INTO "publications_researchers" VALUES (26,10,24,'0.50');
INSERT INTO "publications_researchers" VALUES (27,10,15,'0.50');
INSERT INTO "publications_researchers" VALUES (28,11,15,'1.00');
INSERT INTO "publications_researchers" VALUES (29,12,16,'1.00');
INSERT INTO "publications_researchers" VALUES (30,13,24,'0.50');
INSERT INTO "publications_researchers" VALUES (31,13,15,'0.50');
INSERT INTO "publications_researchers" VALUES (32,14,15,'0.50');
INSERT INTO "publications_researchers" VALUES (33,14,16,'0.50');
INSERT INTO "publications_researchers" VALUES (34,15,21,'0.25');
INSERT INTO "publications_researchers" VALUES (35,15,22,'0.25');
INSERT INTO "publications_researchers" VALUES (36,15,23,'0.25');
INSERT INTO "publications_researchers" VALUES (37,15,15,'0.25');
CREATE TABLE "publications_theme" (
  "idpublications_theme" int(11) NOT NULL ,
  "publicationid" int(11) DEFAULT NULL,
  "themeid" int(11) DEFAULT NULL,
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  PRIMARY KEY ("idpublications_theme")
);
INSERT INTO "publications_theme" VALUES (1,1,1,'0.50');
INSERT INTO "publications_theme" VALUES (2,1,2,'0.50');
INSERT INTO "publications_theme" VALUES (3,2,3,'1.00');
INSERT INTO "publications_theme" VALUES (4,3,4,'0.33');
INSERT INTO "publications_theme" VALUES (5,3,3,'0.33');
INSERT INTO "publications_theme" VALUES (6,3,1,'0.33');
INSERT INTO "publications_theme" VALUES (7,4,2,'1.00');
INSERT INTO "publications_theme" VALUES (8,5,3,'0.50');
INSERT INTO "publications_theme" VALUES (9,5,1,'0.50');
INSERT INTO "publications_theme" VALUES (10,6,2,'0.50');
INSERT INTO "publications_theme" VALUES (11,6,3,'0.50');
INSERT INTO "publications_theme" VALUES (12,7,4,'0.50');
INSERT INTO "publications_theme" VALUES (13,7,3,'0.50');
INSERT INTO "publications_theme" VALUES (14,8,1,'0.50');
INSERT INTO "publications_theme" VALUES (15,8,2,'0.50');
INSERT INTO "publications_theme" VALUES (16,9,3,'0.33');
INSERT INTO "publications_theme" VALUES (17,9,4,'0.33');
INSERT INTO "publications_theme" VALUES (18,9,3,'0.33');
INSERT INTO "publications_theme" VALUES (21,10,3,'1.00');
INSERT INTO "publications_theme" VALUES (22,11,4,'0.50');
INSERT INTO "publications_theme" VALUES (23,11,1,'0.50');
INSERT INTO "publications_theme" VALUES (24,12,2,'0.50');
INSERT INTO "publications_theme" VALUES (25,12,3,'0.50');
INSERT INTO "publications_theme" VALUES (26,13,4,'0.33');
INSERT INTO "publications_theme" VALUES (27,13,1,'0.33');
INSERT INTO "publications_theme" VALUES (28,13,2,'0.33');
INSERT INTO "publications_theme" VALUES (29,14,4,'0.33');
INSERT INTO "publications_theme" VALUES (30,14,1,'0.33');
INSERT INTO "publications_theme" VALUES (31,14,2,'0.33');
INSERT INTO "publications_theme" VALUES (32,15,3,'0.50');
INSERT INTO "publications_theme" VALUES (33,15,4,'0.50');
CREATE TABLE "researchers" (
  "idresearchers" int(11) NOT NULL,
  "name" varchar(45) DEFAULT NULL,
  "iddepartments" int(11) DEFAULT NULL,
  PRIMARY KEY ("idresearchers")
);
INSERT INTO "researchers" VALUES (1,'Researcher 1',1);
INSERT INTO "researchers" VALUES (2,'Researcher 2',2);
INSERT INTO "researchers" VALUES (3,'Researcher 3',2);
INSERT INTO "researchers" VALUES (4,'Researcher 4',3);
INSERT INTO "researchers" VALUES (5,'Researcher 5',3);
INSERT INTO "researchers" VALUES (6,'Researcher 6',4);
INSERT INTO "researchers" VALUES (7,'Researcher 7',5);
INSERT INTO "researchers" VALUES (8,'Researcher 8',6);
INSERT INTO "researchers" VALUES (9,'Researcher 9',6);
INSERT INTO "researchers" VALUES (10,'Researcher 10',7);
INSERT INTO "researchers" VALUES (11,'Researcher 11',7);
CREATE TABLE "staff_hierarchy" (
  "idhierarchy" int(11) NOT NULL ,
  "parentid" int(11) DEFAULT NULL,
  "level" int(11) DEFAULT NULL,
  "original_id" int(11) DEFAULT NULL,
  "origin_parent" int(11) DEFAULT NULL,
  "label" varchar(105) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "staff_hierarchy" VALUES (1,0,1,1,0,'Faculty of IT');
INSERT INTO "staff_hierarchy" VALUES (2,0,1,2,0,'Faculty of Science');
INSERT INTO "staff_hierarchy" VALUES (3,0,1,3,0,'Faculty of Business');
INSERT INTO "staff_hierarchy" VALUES (4,0,1,4,0,'Faculty of Medicine');
INSERT INTO "staff_hierarchy" VALUES (8,1,2,1,1,'Department of IT');
INSERT INTO "staff_hierarchy" VALUES (9,1,2,2,1,'Department of IT 2');
INSERT INTO "staff_hierarchy" VALUES (10,2,2,3,2,'Department of Science');
INSERT INTO "staff_hierarchy" VALUES (11,2,2,4,2,'Department of Science 2');
INSERT INTO "staff_hierarchy" VALUES (12,3,2,5,3,'Department of Business');
INSERT INTO "staff_hierarchy" VALUES (13,3,2,6,3,'Department of Business 2');
INSERT INTO "staff_hierarchy" VALUES (14,4,2,7,4,'Department of Medicine');
INSERT INTO "staff_hierarchy" VALUES (15,8,3,1,1,'Researcher 1');
INSERT INTO "staff_hierarchy" VALUES (16,9,3,2,2,'Researcher 2');
INSERT INTO "staff_hierarchy" VALUES (17,9,3,3,2,'Researcher 3');
INSERT INTO "staff_hierarchy" VALUES (18,10,3,4,3,'Researcher 4');
INSERT INTO "staff_hierarchy" VALUES (19,10,3,5,3,'Researcher 5');
INSERT INTO "staff_hierarchy" VALUES (20,11,3,6,4,'Researcher 6');
INSERT INTO "staff_hierarchy" VALUES (21,12,3,7,5,'Researcher 7');
INSERT INTO "staff_hierarchy" VALUES (22,13,3,8,6,'Researcher 8');
INSERT INTO "staff_hierarchy" VALUES (23,13,3,9,6,'Researcher 9');
INSERT INTO "staff_hierarchy" VALUES (24,14,3,10,7,'Researcher 10');
INSERT INTO "staff_hierarchy" VALUES (25,14,3,11,7,'Researcher 11');
CREATE TABLE "temptable1" (
  "idforcodes_hierarchy" int(11) NOT NULL DEFAULT '0',
  "parentid" int(11) DEFAULT NULL,
  "Level" int(11) DEFAULT NULL,
  "Orgin_ID" int(11) DEFAULT NULL,
  "Orgin_parent" int(11) DEFAULT NULL,
  "Label" varchar(95) DEFAULT NULL
);
INSERT INTO "temptable1" VALUES (8,1,2,1,1,'11000');
INSERT INTO "temptable1" VALUES (9,2,2,2,2,'21000');
INSERT INTO "temptable1" VALUES (10,3,2,3,3,'31000');
INSERT INTO "temptable1" VALUES (11,4,2,4,4,'41000');
INSERT INTO "temptable1" VALUES (12,4,2,5,4,'42000');
CREATE TABLE "theme" (
  "idtheme" int(11) NOT NULL,
  "name" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("idtheme")
);
INSERT INTO "theme" VALUES (1,'Culture');
INSERT INTO "theme" VALUES (2,'Heritage');
INSERT INTO "theme" VALUES (3,'History');
INSERT INTO "theme" VALUES (4,'Social');
CREATE TABLE "theme_hierarchy" (
  "idhierarchy" int(11) NOT NULL ,
  "parentid" int(11) DEFAULT NULL,
  "original_id" int(11) DEFAULT NULL,
  "origin_parent" int(11) DEFAULT NULL,
  "label" varchar(95) DEFAULT NULL,
  "level" int(11) DEFAULT NULL,
  PRIMARY KEY ("idhierarchy")
);
INSERT INTO "theme_hierarchy" VALUES (1,0,1,0,'Culture',1);
INSERT INTO "theme_hierarchy" VALUES (2,0,2,0,'Heritage',1);
INSERT INTO "theme_hierarchy" VALUES (3,0,3,0,'History',1);
INSERT INTO "theme_hierarchy" VALUES (4,0,4,0,'Social',1);
CREATE TABLE "tmptable" (
  "weighted_sum" decimal(10,2) DEFAULT NULL,
  "parentid" int(11) DEFAULT NULL
);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.33',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('1.00',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.33',0);
INSERT INTO "tmptable" VALUES ('0.33',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.33',0);
INSERT INTO "tmptable" VALUES ('0.33',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.33',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.33',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('1.00',0);
INSERT INTO "tmptable" VALUES ('0.33',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.33',0);
INSERT INTO "tmptable" VALUES ('0.33',0);
INSERT INTO "tmptable" VALUES ('1.00',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
INSERT INTO "tmptable" VALUES ('0.33',0);
INSERT INTO "tmptable" VALUES ('0.33',0);
INSERT INTO "tmptable" VALUES ('0.50',0);
END TRANSACTION;
